function getWidjet(){
    let color = 'rgb(163, 129, 255)'
    let orderWidjetObject;
    document.querySelectorAll('[data-widget-type="COMBINED_ORDER_WIDGET"]').forEach(function (widjet) {
        if (widjet.querySelector(`div[style*='${color}']`)) {
            orderWidjetObject = widjet;
        }
    })
    return orderWidjetObject;
}

function setTicker(ticker) {
    // $0.__reactInternalInstance$8m7815qidcc.memoizedProps.children[1][2]["_owner"]["memoizedProps"].selectSymbol('INTC')
    //10-я группа
    //почему-то реальный цвет со style не совпадает
    let orderWidjetObject=getWidjet();
    if (!orderWidjetObject) {
        console.error('Виджет не найден')
        return 0;
    }
    let reactObjectName = Object.keys(orderWidjetObject).find(function (key) {
        return key.startsWith("__reactInternalInstance$")
    });

    let target = orderWidjetObject[reactObjectName].memoizedProps.children.find(function (child) {
        return Array.isArray(child)
    }).find(function (item) {
        return item._owner.memoizedProps.selectSymbol
    });

    target._owner.memoizedProps.selectSymbol(ticker)
}

chrome.runtime.sendMessage(the2358Id,
    {query: "getToken"},
    function (token) {
        if (token) {
            const ioClient = io("wss://bot.oost.app:2358", {
                query: {token: token},
                transports: ['websocket']
            });

            ioClient.on('ticker', (ticker) => {
                console.log('setTicker: ' + ticker)
                setTicker(ticker)
            })

            ioClient.on("connect", () => {
                chrome.runtime.sendMessage(the2358Id,
                    {query: "connectedStatus",status:ioClient.connected}
                );
            });

            ioClient.on("disconnect", () => {
                chrome.runtime.sendMessage(the2358Id,
                    {query: "connectedStatus",status:ioClient.connected}
                );
            });
        } else {
            console.error('Токен не установлен')
        }
    })



    let target = document.querySelector('body');
    let observeTimer;
// Конфигурация observer (за какими изменениями наблюдать)
    const config = {
        attributes: false,
        childList: true,
        subtree: true
    };

// Колбэк-функция при срабатывании мутации
    const callback = function (mutationsList, observer) {
        console.log('observer')
        clearTimeout(observeTimer)
        observeTimer=setTimeout(function(){
            console.log('timer')
            chrome.runtime.sendMessage(the2358Id,
                {query: "widgetStatus", status: !!getWidjet()}
            );
        }, 150)
    };

// Создаём экземпляр наблюдателя с указанной функцией колбэка
    const observer = new MutationObserver(callback);

// Начинаем наблюдение за настроенными изменениями целевого элемента
    observer.observe(target, config);