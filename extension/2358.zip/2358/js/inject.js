function injectScript(name){
    let s = document.createElement('script');
    s.src = chrome.runtime.getURL(name);
    s.onload = function() {
        this.remove();
    };
    (document.head || document.documentElement).appendChild(s);
}
let s = document.createElement('script');
s.innerHTML=`let the2358Id='${chrome.runtime.id}'`;
(document.head || document.documentElement).appendChild(s);


let i = document.createElement('img');
i.src=chrome.runtime.getURL('icons/64.png');
i.id='the2358_icon';
i.style.display='none';
(document.head || document.documentElement).appendChild(i);

injectScript("js/io.js")
injectScript("js/index.js")