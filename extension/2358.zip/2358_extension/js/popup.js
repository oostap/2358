chrome.storage.sync.get('token', function (result) {
    document.querySelector("#token").value = result.token
    showMonitor();
})

document.getElementById("save").onclick = function () {
    chrome.storage.sync.set({"token": document.querySelector("#token").value});
}


function showMonitor(){
    if(!!document.querySelector('input#token').value){
        document.querySelector('div#monitor').style.display='';
        chrome.runtime.sendMessage(
            {query: "getStats"},
            function (result) {
                document.querySelector('#connected-label').classList.toggle('red',!result.connected)
                document.querySelector('#widget-label').classList.toggle('red',!result.widget)
            })
    } else {
        document.querySelector('div#monitor').style.display='none';
    }
}

document.querySelector("sup").innerText=" v"+chrome.runtime.getManifest().version