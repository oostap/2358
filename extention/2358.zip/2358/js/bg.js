chrome.runtime.onMessageExternal.addListener(
    function (request, sender, sendResponse) {
        if (request.query == "getToken") {
            chrome.storage.sync.get('token', async function (result) {
                console.log(result)
                sendResponse(result.token)
            })
        }

    }
)

chrome.runtime.onInstalled.addListener(function() {
    chrome.declarativeContent.onPageChanged.removeRules(undefined, function() {
        chrome.declarativeContent.onPageChanged.addRules([{
            conditions: [new chrome.declarativeContent.PageStateMatcher({
                pageUrl: {
                    hostContains: "tinkoff.ru",
                    schemes: ["https"]
                }
            })
            ],
            actions: [
                new chrome.declarativeContent.ShowPageAction(),
            ]
        }]);
    });
});
