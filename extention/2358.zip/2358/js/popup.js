chrome.storage.sync.get('token', function (result) {
    document.querySelector("#token").value = result.token
})

document.getElementById("save").onclick = function () {
    chrome.storage.sync.set({"token": document.querySelector("#token").value});
}
