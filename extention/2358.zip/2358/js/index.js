function setTicker(ticker) {
    // $0.__reactInternalInstance$8m7815qidcc.memoizedProps.children[1][2]["_owner"]["memoizedProps"].selectSymbol('INTC')
    //10-я группа
    //почему-то реальный цвет со style не совпадает
    let color = 'rgb(163, 129, 255)'
    let orderWidjetObject;
    document.querySelectorAll('[data-widget-type="COMBINED_ORDER_WIDGET"]').forEach(function (widjet) {
        if (widjet.querySelector(`div[style*='${color}']`)) {
            orderWidjetObject = widjet;
        }
    })
    if (!orderWidjetObject) {
        console.error('Виджет не найден')
        return 0;
    }
    let reactObjectName = Object.keys(orderWidjetObject).find(function (key) {
        return key.startsWith("__reactInternalInstance$")
    });

    let target = orderWidjetObject[reactObjectName].memoizedProps.children.find(function (child) {
        return Array.isArray(child)
    }).find(function (item) {
        return item._owner.memoizedProps.selectSymbol
    });

    target._owner.memoizedProps.selectSymbol(ticker)
}

chrome.runtime.sendMessage(the2358Id,
    {query: "getToken"},
    function (token) {
        if (token) {
            const ioClient = io("wss://bot.oost.app:2358", {
                query: {token: token},
                transports: ['websocket']
            });

            ioClient.on('ticker', (ticker) => {
                console.log('setTicker: ' + ticker)
                setTicker(ticker)
            })
        } else {
            console.error('Токен не установлен')
        }
    })

