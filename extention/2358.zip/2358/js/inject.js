function injectScript(name){
    let s = document.createElement('script');
    s.src = chrome.runtime.getURL(name);
    s.onload = function() {
        this.remove();
    };
    (document.head || document.documentElement).appendChild(s);
}
let s = document.createElement('script');
s.innerHTML=`let the2358Id='${chrome.runtime.id}'`;
(document.head || document.documentElement).appendChild(s);
injectScript("js/io.js")
injectScript("js/index.js")